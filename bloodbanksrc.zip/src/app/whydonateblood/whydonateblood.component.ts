import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whydonateblood',
  templateUrl: './whydonateblood.component.html',
  styleUrls: ['./whydonateblood.component.css']
})
export class WhydonatebloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
