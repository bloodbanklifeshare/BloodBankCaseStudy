import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class BbserviceService {

  private myUrl = "http://localhost:8080/BloodBankws/rest/bbs/donorreg";
  private myUrl2 = "http://localhost:8080/BloodBankws/rest/bbs/patreg";
  private myUrl3 = "http://localhost:8080/BloodBankws/rest/bbs/dlogin";
  private myUrl4 = "http://localhost:8080/BloodBankws/rest/bbs/plogin";
  private myUrl5 = "http://localhost:8080/BloodBankws/rest/bbs/donorupd";
  private myUrl6 = "http://localhost:8080/BloodBankws/rest/bbs/dsearch";
  private myUrl7 = "http://localhost:8080/BloodBankws/rest/bbs/dbgsearch";
  private myUrl8 = "http://localhost:8080/BloodBankws/rest/bbs/ddelete";
  private myUrl9 = "http://localhost:8080/BloodBankws/rest/bbs/setuser";
  private myUrl10 = "http://localhost:8080/BloodBankws/rest/bbs/user";

  username: String;
  password: String;
  name: String;
  gender: String;
  email: String;
  dob: String;
  bloodgroup: String;
  mobile: String;
  weight: String;
  address: String;
  state: String;
  city: String;
  httpdata;

  constructor(private http: Http, private router: Router) {

  }

  regDonor(name, username, password, dob, gender, bgroup, weight, mnumber, address, email, state, city) {
    let s = this.myUrl + "/" + name + "/" + username + "/" + password + "/" + dob + "/" + gender + "/" + bgroup + "/" + weight + "/" + mnumber + "/" + address + "/" + email + "/" + state + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/login');
    return this.httpdata;

  }
  regPatient(name, username, password, email, bgroup, mobile) {
    let s = this.myUrl2 + "/" + name + "/" + username + "/" + password + "/" + email + "/" + bgroup + "/" + mobile;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/login');
    return this.httpdata;
  }
  DLogin(username, password) {

    let s = this.myUrl3 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));

    return this.httpdata;

  }
  PLogin(username, password) {
    let s = this.myUrl4 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  updDonor(name, username, password, dob, gender, bgroup, weight, mnumber, address, email, state, city) {
    let s = this.myUrl5 + "/" + name + "/" + username + "/" + password + "/" + dob + "/" + gender + "/" + bgroup + "/" + weight + "/" + mnumber + "/" + address + "/" + email + "/" + state + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  dsearch(city) {
    let s = this.myUrl6 + "/" + city;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  dbgsearch(bloodgroup) {
    let s = this.myUrl7 + "/" + bloodgroup;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  ddelete(username) {
    let s = this.myUrl8 + "/" + username;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  displaydata(data) {this.httpdata = data;}

}



