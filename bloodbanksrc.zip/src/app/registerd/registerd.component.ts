import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';

import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-registerd',
  templateUrl: './registerd.component.html',
  styleUrls: ['./registerd.component.css'],
  providers: [BbserviceService]
})
export class RegisterdComponent implements OnInit {
  username: String;
  password: String;
  name: String;
  gender: String;
  email: String;
  dob: String;
  bloodgroup: String;
  mobile: String;
  weight: String;
  address: String;
  state: String;
  city: String;
  constructor(private iServe: BbserviceService) {}

  onSubmit(form: NgForm) {
    this.iServe.regDonor(this.name, this.username, this.password, this.dob, this.gender, this.bloodgroup, this.weight, this.mobile, this.address, this.email, this.state, this.city);
  }

  ngOnInit() {
  }

}
