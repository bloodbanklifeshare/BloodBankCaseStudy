import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-registerp',
  templateUrl: './registerp.component.html',
  styleUrls: ['./registerp.component.css'],
  providers: [BbserviceService]


})
export class RegisterpComponent implements OnInit {
  username: String;
  password: String;
  name: String;
  email: String;
  httpdata;
  bloodgroup: String;
  mobile: String;

  constructor(private iServe: BbserviceService) {}

  onSubmit(form: NgForm) {
    this.iServe.regPatient(this.name, this.username, this.password, this.email, this.bloodgroup, this.mobile);
  }
  ngOnInit() {
  }

}
