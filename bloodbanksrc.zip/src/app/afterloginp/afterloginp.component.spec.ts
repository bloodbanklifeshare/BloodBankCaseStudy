import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AfterloginpComponent } from './afterloginp.component';

describe('AfterloginpComponent', () => {
  let component: AfterloginpComponent;
  let fixture: ComponentFixture<AfterloginpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AfterloginpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AfterloginpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
