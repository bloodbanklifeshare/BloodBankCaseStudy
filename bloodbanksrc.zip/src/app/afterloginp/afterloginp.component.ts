import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';

import {Http, Response} from '@angular/http';
import {Router} from '@angular/router';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-afterloginp',
  templateUrl: './afterloginp.component.html',
  styleUrls: ['./afterloginp.component.css'],
  providers: [BbserviceService]
})
export class AfterloginpComponent implements OnInit {
  myUrl6 = "http://localhost:8080/BloodBankws/rest/bbs/dsearch";
  private myUrl7 = "http://localhost:8080/BloodBankws/rest/bbs/dbgsearch";
  city: String;
  bloodgroup: String;
  datahttp: any;
  httpdata: any;
  constructor(private iServe: BbserviceService, private router: Router) {}
  onClicked(event) {
    this.router.navigateByUrl('/home');
  }
  onSubmit1(form: NgForm) {
    this.datahttp = this.iServe.dsearch(this.city);



  }
  onSubmit(form: NgForm) {
    this.httpdata = this.iServe.dbgsearch(this.bloodgroup);

  }
  ngOnInit() {
  }

}
