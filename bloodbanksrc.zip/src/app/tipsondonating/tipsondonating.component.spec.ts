import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TipsondonatingComponent } from './tipsondonating.component';

describe('TipsondonatingComponent', () => {
  let component: TipsondonatingComponent;
  let fixture: ComponentFixture<TipsondonatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TipsondonatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TipsondonatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
