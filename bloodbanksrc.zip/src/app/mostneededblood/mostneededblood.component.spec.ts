import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostneededbloodComponent } from './mostneededblood.component';

describe('MostneededbloodComponent', () => {
  let component: MostneededbloodComponent;
  let fixture: ComponentFixture<MostneededbloodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostneededbloodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostneededbloodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
