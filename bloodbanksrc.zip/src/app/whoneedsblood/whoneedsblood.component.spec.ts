import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhoneedsbloodComponent } from './whoneedsblood.component';

describe('WhoneedsbloodComponent', () => {
  let component: WhoneedsbloodComponent;
  let fixture: ComponentFixture<WhoneedsbloodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhoneedsbloodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhoneedsbloodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
