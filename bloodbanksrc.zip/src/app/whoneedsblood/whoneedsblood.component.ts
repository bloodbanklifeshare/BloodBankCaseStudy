import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whoneedsblood',
  templateUrl: './whoneedsblood.component.html',
  styleUrls: ['./whoneedsblood.component.css']
})
export class WhoneedsbloodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
