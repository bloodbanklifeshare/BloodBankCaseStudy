import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';

import {Http, Response} from '@angular/http';
import {Router} from '@angular/router';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-loginp',
  templateUrl: './loginp.component.html',
  styleUrls: ['./loginp.component.css'],
  providers: [BbserviceService]
})

export class LoginpComponent implements OnInit {
  username: String;
  password: String;
  datahttp: any[];
  status: String;
  constructor(private iServe: BbserviceService, private router: Router) {}
  onSubmit(form: NgForm) {

    this.datahttp = this.iServe.PLogin(this.username, this.password);
    if (this.datahttp != null) {
      let sta = this.datahttp[0]["status"];
      if (sta === 'SUCCESS') {
        this.router.navigateByUrl('/afterloginp');

      }

      else {
        this.displaydata();
      }
    }


  }

  displaydata() {
    this.status = 'Login UnSuccessful';

    return status;
  }

  ngOnInit() {
  }

}
