import {BbserviceService} from '../bbservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import {NgModule} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Router} from '@angular/router';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-afterlogind',
  templateUrl: './afterlogind.component.html',
  styleUrls: ['./afterlogind.component.css'],
  providers: [BbserviceService]
})
export class AfterlogindComponent implements OnInit {
  username: String;
  password: String;
  name: String;
  gender: String;
  email: String;
  dob: String;
  bloodgroup: String;
  mobile: String;
  weight: String;
  address: String;
  state: String;
  city: String;
  uname: String;
  datahttp: any[];
  status: String;
  httpdata;
  datahttp1;
  status1: String;
  constructor(private iServe: BbserviceService, private router: Router, private http: Http) {


  }

  onClicked(event) {

    this.router.navigateByUrl('/home');
  }


  onSubmit(form: NgForm) {
    this.datahttp1 = this.iServe.updDonor(this.name, this.username, this.password, this.dob, this.gender, this.bloodgroup, this.weight, this.mobile, this.address, this.email, this.state, this.city);
    if (this.datahttp1 != null) {
      let sta = this.datahttp1[0]["status"];
      if (sta === 'DONE') {
        this.router.navigateByUrl('/home');
      }

      else {

        this.displaydata1();
      }
    }
  }

  onSubmit1(form: NgForm) {
    this.datahttp = this.iServe.ddelete(this.uname);
    if (this.datahttp != null) {
      let sta = this.datahttp[0]["status"];
      if (sta == 'DONE') {
        this.router.navigateByUrl('/home');
      }

      else {

        this.displaydata();
      }
    }
  }
  displaydata() {
    this.status = 'Username Not Found';

    return this.status;
  }
  displaydata1() {
    this.status1 = 'Name Cannot Change';

    return this.status1;
  }

  ngOnInit() {
  }

}

