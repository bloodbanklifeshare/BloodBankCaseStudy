package com.bbs.servs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.bbs.servs.*;

@Path("bbs")
public class BBServe {

	@GET
	@Path("/donorreg/{name}/{username}/{password}/{dob}/{gender}/{bgroup}/{weight}/{mobile}/{address}/{email}/{state}/{city}")
	public String regDonor(@PathParam("name") String name, @PathParam("username") String username,
			@PathParam("password") String password, @PathParam("dob") String dob, @PathParam("gender") String gender,
			@PathParam("bgroup") String bgroup, @PathParam("weight") String weight, @PathParam("mobile") String mobile,
			@PathParam("address") String address, @PathParam("email") String email, @PathParam("state") String state,
			@PathParam("city") String city) {
		String staStr = "";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		BasicDBObject bObj = new BasicDBObject("Name", name);
		bObj.append("Username", username).append("Password", password).append("DOB", dob).append("Gender", gender)
				.append("BloodGroup", bgroup).append("weight", weight).append("Mobile", mobile)
				.append("Address", address).append("Email", email).append("State", state).append("City", city);
		coll.insert(bObj);
		return staStr;
	}

	@GET
	@Path("patReg/{name}/{username}/{password}/{email}/{bgroup}/{mobile}")
	public String patReg(@PathParam("name") String name, @PathParam("username") String username,
			@PathParam("password") String password, @PathParam("email") String email,
			@PathParam("bgroup") String bgroup, @PathParam("mobile") String mobile) {
		String pstaStr = "";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection pcoll = db.getCollection("patient");
		BasicDBObject pbObj = new BasicDBObject("name", name);
		pbObj.append("Username", username).append("Password", password).append("Email", email)
				.append("BloodGroup", bgroup).append("Mobile", mobile);
		pcoll.insert(pbObj);
		return pstaStr;
	}

	@GET
	@Path("donorupd/{name}/{username}/{password}/{dob}/{gender}/{bgroup}/{weight}/{mobile}/{address}/{email}/{state}/{city}")
	public String donrupd(@PathParam("name") String name, @PathParam("username") String username,
			@PathParam("password") String password, @PathParam("dob") String dob, @PathParam("gender") String gender,
			@PathParam("bgroup") String bgroup, @PathParam("weight") String weight, @PathParam("mobile") String mobile,
			@PathParam("address") String address, @PathParam("email") String email, @PathParam("state") String state,
			@PathParam("city") String city) {
		String supd = "[{\"status\":\"NotDone\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		BasicDBObject uObj = new BasicDBObject("Name", name);
		String dname = "", duname = "", dpass = "", ddob = "", dgender = "", dbgroup = "", dweight = "", dmobile = "",
				daddress = "", demail = "", dstate = "", dcity = "";
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject dObj = new BasicDBObject();
			dObj = (BasicDBObject) cursor.next();
			String tname = (String) dObj.get("Name");
			if (tname != null) {
				if (tname.equals(name)) {
					dname = tname;
					duname = (String) dObj.get("Username");
					dpass = (String) dObj.get("Password");
					ddob = (String) dObj.get("DOB");
					dgender = (String) dObj.get("Gender");
					dbgroup = (String) dObj.get("BloodGroup");
					dweight = (String) dObj.get("weight");
					dmobile = (String) dObj.get("Mobile");
					daddress = (String) dObj.get("Address");
					demail = (String) dObj.get("Email");
					dstate = (String) dObj.get("State");
					dcity = (String) dObj.get("City");
					BasicDBObject ddObj = new BasicDBObject();
					ddObj.append("Name", name);
					ddObj.append("Username", username);
					ddObj.append("Password", password);
					ddObj.append("DOB", dob);
					ddObj.append("Gender", gender);
					ddObj.append("BloodGroup", bgroup);
					ddObj.append("weight", weight);
					ddObj.append("Mobile", mobile);
					ddObj.append("Address", address);
					ddObj.append("Email", email);
					ddObj.append("State", state);
					ddObj.append("City", city);
					coll.update(uObj, ddObj);
					supd = "[{\"status\":\"DONE\"}]";
				}
			}
		}
		return supd;

	}

	@GET
	@Path("/dlogin/{username}/{password}")
	public String dLogin(@PathParam("username") String username, @PathParam("password") String password) {
		String sLogin = "[{\"status\":\"FAILURE\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		String pPassword = "";
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject pObj = new BasicDBObject();
			pObj = (BasicDBObject) cursor.next();
			String uname = (String) pObj.get("Username");
			String pwd = (String) pObj.get("Password");
			if (uname != null) {
				if (uname.trim().equals(username)) {
					pPassword = pwd;
					break;
				}
			}
		}
		if (pPassword.equals(password)) {
			sLogin = "[{\"status\":\"SUCCESS\"}]";
		}
		return sLogin;
	}

	@GET
	@Path("/plogin/{username}/{password}")
	public String pLogin(@PathParam("username") String username, @PathParam("password") String password) {
		String sLogin = "[{\"status\":\"FAILURE\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("patient");
		String dPassword = "";
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject dObj = new BasicDBObject();
			dObj = (BasicDBObject) cursor.next();
			String uname = (String) dObj.get("Username");
			String pwd = (String) dObj.get("Password");
			if (uname != null) {
				if (uname.trim().equals(username)) {
					dPassword = pwd;
					break;
				}
			}
		}
		if (dPassword.equals(password)) {
			sLogin = "[{\"status\":\"SUCCESS\"}]";
		}
		return sLogin;
	}

	@GET
	@Path("/dsearch/{city}")
	public String retDonors(@PathParam("city") String city) {
		List<Donor> dList = new ArrayList<>();
		String retsJSON = "";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject obj = (BasicDBObject) cursor.next();
			String dCity = "";
			dCity = (String) obj.get("City");
			if (dCity != null) {
				if (dCity.toLowerCase().equals(city.toLowerCase())) {
					Donor dd = new Donor();
					dd.setName((String) obj.get("Name"));
					dd.setGender((String) obj.get("Gender"));
					dd.setBloodgroup((String) obj.get("BloodGroup"));
					dd.setWeight((String) obj.get("weight"));
					dd.setMobile((String) obj.get("Mobile"));
					dd.setAddress((String) obj.get("Address"));
					dd.setEmail((String) obj.get("Email"));
					dd.setCity((String) obj.get("City"));
					dd.setState((String) obj.get("State"));
					dList.add(dd);
				}
			}
		}
		ObjectMapper omap = new ObjectMapper();
		try {
			retsJSON = omap.writeValueAsString(dList);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retsJSON;
	}

	@GET
	@Path("/dbgsearch/{bloodgroup}")
	public String retDonorbg(@PathParam("bloodgroup") String bloodgroup) {
		List<Donor> dList = new ArrayList<>();
		String retsJSON = "";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject obj = (BasicDBObject) cursor.next();
			String dGroup = "";
			dGroup = (String) obj.get("BloodGroup");
			if (dGroup != null) {
				if (dGroup.equals(bloodgroup)) {
					Donor dd = new Donor();
					dd.setName((String) obj.get("Name"));
					dd.setGender((String) obj.get("Gender"));
					dd.setBloodgroup((String) obj.get("BloodGroup"));
					dd.setWeight((String) obj.get("weight"));
					dd.setMobile((String) obj.get("Mobile"));
					dd.setAddress((String) obj.get("Address"));
					dd.setEmail((String) obj.get("Email"));
					dd.setCity((String) obj.get("City"));
					dd.setState((String) obj.get("State"));
					dList.add(dd);
				}
			}
		}
		ObjectMapper omap = new ObjectMapper();
		try {
			retsJSON = omap.writeValueAsString(dList);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retsJSON;
	}

	@GET
	@Path("/ddelete/{username}")
	public String delDonor(@PathParam("username") String username) {
		String status = "[{\"status\":\"NOTDONE\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("BloodBank");
		DBCollection coll = db.getCollection("donor");
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject dObj = new BasicDBObject();
			dObj = (BasicDBObject) cursor.next();
			String uname = (String) dObj.get("Username");
			if (uname.trim().equals(username)) {
				BasicDBObject obj = new BasicDBObject("Username", username);
				coll.remove(obj);
				status = "[{\"status\":\"DONE\"}]";
			}
		}
		return status;

	}

}